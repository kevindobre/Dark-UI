﻿using UnityEngine;
using UnityEditor;

namespace NaughtyAttributes.Editor
{
    public class MaxValuePropertyValidator : PropertyValidatorBase
    {
        public override void ValidateProperty(SerializedProperty property)
        {
            MaxValueAttribute maxValueAttribute = PropertyUtility.GetAttribute<MaxValueAttribute>(property);
            float maxValue = maxValueAttribute.MaxValue;
            if (!string.IsNullOrEmpty(maxValueAttribute.MaxValueName))
            {
                if (!PropertyUtility.TryGetNumericValue(property, maxValueAttribute.MaxValueName, out maxValue))
                {
                    string warning = string.Format(
                        "{0} could not resolve '{1}' to a numeric field, property, or parameterless method on {2}",
                        nameof(MaxValueAttribute), maxValueAttribute.MaxValueName, property.serializedObject.targetObject.GetType().Name);
                    Debug.LogWarning(warning, property.serializedObject.targetObject);
                    return;
                }
            }

            if (property.propertyType == SerializedPropertyType.Integer)
            {
                if (property.intValue > maxValue)
                {
                    property.intValue = (int)maxValue;
                }
            }
            else if (property.propertyType == SerializedPropertyType.Float)
            {
                if (property.floatValue > maxValue)
                {
                    property.floatValue = maxValue;
                }
            }
            else if (property.propertyType == SerializedPropertyType.Vector2)
            {
                property.vector2Value = Vector2.Min(property.vector2Value, new Vector2(maxValue, maxValue));
            }
            else if (property.propertyType == SerializedPropertyType.Vector3)
            {
                property.vector3Value = Vector3.Min(property.vector3Value, new Vector3(maxValue, maxValue, maxValue));
            }
            else if (property.propertyType == SerializedPropertyType.Vector4)
            {
                property.vector4Value = Vector4.Min(property.vector4Value, new Vector4(maxValue, maxValue, maxValue, maxValue));
            }
            else if (property.propertyType == SerializedPropertyType.Vector2Int)
            {
                property.vector2IntValue = Vector2Int.Min(property.vector2IntValue, new Vector2Int((int)maxValue, (int)maxValue));
            }
            else if (property.propertyType == SerializedPropertyType.Vector3Int)
            {
                property.vector3IntValue = Vector3Int.Min(property.vector3IntValue, new Vector3Int((int)maxValue, (int)maxValue, (int)maxValue));
            }
            else
            {
                string warning = maxValueAttribute.GetType().Name + " can be used only on int, float, Vector or VectorInt fields";
                Debug.LogWarning(warning, property.serializedObject.targetObject);
            }
        }
    }
}
